import 'package:flutter/material.dart';
import '../models/student.dart';
import '../models/course.dart';

class StudentProfileScreen extends StatelessWidget {
  final Student? student;
  final Course? course;

  StudentProfileScreen({
    required this.student,
    required this.course,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Perfil do Aluno'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.home),
            onPressed: () {
              Navigator.pushNamedAndRemoveUntil(
                context,
                '/',
                (route) => false,
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(24),
        child: Center(
          child: Container(
            constraints: BoxConstraints(maxWidth: 800),
            child: Column(
              children: [
                _buildStudentCard(),
                SizedBox(height: 24),
                if (course != null) _buildCourseCard(),
                SizedBox(height: 24),
                _buildActionButtons(context),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStudentCard() {
    return Card(
      child: Padding(
        padding: EdgeInsets.all(32),
        child: Column(
          children: [
            CircleAvatar(
              radius: 50,
              backgroundColor: Color(0xFF1B365D),
              child: Icon(
                Icons.person,
                size: 60,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 24),
            Text(
              student?.name ?? 'Nome não informado',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Color(0xFF1B365D),
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 24),
            _buildInfoRow(Icons.email, 'E-mail', student?.email ?? 'Não informado'),
            SizedBox(height: 16),
            _buildInfoRow(Icons.phone, 'Telefone', student?.phone ?? 'Não informado'),
            SizedBox(height: 16),
            _buildInfoRow(
              Icons.calendar_today,
              'Data de Nascimento',
              student?.formattedBirthDate ?? 'Não informado',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCourseCard() {
    return Card(
      child: Padding(
        padding: EdgeInsets.all(32),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  _getCourseIcon(course!.name),
                  size: 32,
                  color: Color(0xFF1B365D),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: Text(
                    'Curso Selecionado',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF1B365D),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 24),
            Text(
              course!.name,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8),
            Text(
              course!.description,
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey[600],
              ),
            ),
            SizedBox(height: 16),
            Row(
              children: [
                Icon(
                  Icons.access_time,
                  size: 20,
                  color: Colors.grey[600],
                ),
                SizedBox(width: 8),
                Text(
                  'Duração: ${course!.duration} semestres',
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey[600],
                  ),
                ),
              ],
            ),
            SizedBox(height: 24),
            Text(
              'Grade Curricular (${course!.subjects.length} matérias):',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color(0xFF1B365D),
              ),
            ),
            SizedBox(height: 16),
            GridView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 4,
                crossAxisSpacing: 8,
                mainAxisSpacing: 8,
              ),
              itemCount: course!.subjects.length,
              itemBuilder: (context, index) {
                return Container(
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Color(0xFFD7D7D7),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.book,
                        size: 16,
                        color: Color(0xFF1B365D),
                      ),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          course!.subjects[index],
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Row(
      children: [
        Icon(
          icon,
          size: 20,
          color: Color(0xFF1B365D),
        ),
        SizedBox(width: 12),
        Text(
          '$label: ',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Color(0xFF1B365D),
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: TextStyle(
              fontSize: 16,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildActionButtons(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        ElevatedButton.icon(
          onPressed: () {
            Navigator.pushNamed(context, '/register');
          },
          icon: Icon(Icons.person_add),
          label: Text('Novo Aluno'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.green,
            padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          ),
        ),
        ElevatedButton.icon(
          onPressed: () {
            Navigator.pushNamed(context, '/courses');
          },
          icon: Icon(Icons.school),
          label: Text('Trocar Curso'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.orange,
            padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          ),
        ),
      ],
    );
  }

  IconData _getCourseIcon(String courseName) {
    switch (courseName) {
      case 'Ciência da Computação':
        return Icons.computer;
      case 'Administração':
        return Icons.business;
      case 'Design Gráfico':
        return Icons.palette;
      default:
        return Icons.school;
    }
  }
}
